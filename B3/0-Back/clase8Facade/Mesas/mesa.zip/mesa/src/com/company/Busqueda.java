package com.company;

public interface Busqueda {
    String buscar( Hotel hotel, Vuelo vuelo);
}
