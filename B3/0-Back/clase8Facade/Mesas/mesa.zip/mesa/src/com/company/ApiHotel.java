package com.company;

public class ApiHotel {
}
