package com.dh.facade.service;

import com.dh.facade.service.proveedores.ProveedorA;
import com.dh.facade.service.proveedores.ProveedorB;
import com.dh.facade.service.proveedores.ProveedorC;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class BuscadorImpl implements IBuscadorFacade {
    private ProveedorA proveedorA;
    private ProveedorB proveedorB;
    private ProveedorC proveedorC;

    public BuscadorImpl(ProveedorA proveedorA, ProveedorB proveedorB, ProveedorC proveedorC) {
        this.proveedorA = proveedorA;
        this.proveedorB = proveedorB;
        this.proveedorC = proveedorC;
    }
    // Vamos a traer los vuelos desde los diferentes proveedores, los agrupamos y los devolvemos
    @Override
    public List<Map<String, String>> buscarVuelo(Date fechaDesde, Date fechaHasta, String origen, String destino) {
        List<Map<String, String>> vuelos = new ArrayList();

        vuelos.add(proveedorA.buscar(fechaDesde,fechaHasta,origen,destino));
        vuelos.add(proveedorB.buscar(fechaDesde,fechaHasta,origen,destino));
        vuelos.add(proveedorC.buscar(fechaDesde,fechaHasta,origen,destino));

        return vuelos;
    }
}
