package com.dh.facade.service.proveedores;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ProveedorB {

    public Map<String,String> buscar(Date fechaDesde, Date fechaHasta, String hasta, String desde){
        Map<String,String> vuelo = new HashMap<>();
        vuelo.put("vueloId","123");
        vuelo.put("desde","Buenos Aires, Argentina");
        vuelo.put("hacia","Bogotá, Colombia");
        vuelo.put("fecha","2/7/2021");
        vuelo.put("valorDesde","$80.529");
        vuelo.put("proveedor","ProveedorB");
        return vuelo; //Para el caso practico, simulamos la llamada a otro servicio
    }
}
