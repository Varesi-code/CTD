package com.dh.facade.service.proveedores;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ProveedorC {

    public Map<String,String> buscar(Date fechaDesde, Date fechaHasta, String hasta, String desde){
        Map<String,String> vuelo = new HashMap<>();
        vuelo.put("vueloId","1234");
        vuelo.put("desde","Ezeiza, Argentina");
        vuelo.put("hacia","Cartagena, Colombia");
        vuelo.put("fecha","1/7/2021");
        vuelo.put("valorDesde","$84.529");

        vuelo.put("proveedor","ProveedorD");
        return vuelo; //Para el caso practico, simulamos la llamada a otro servicio
    }
}
