package com.dh.facade;

import com.dh.facade.service.BuscadorImpl;
import com.dh.facade.service.IBuscadorFacade;
import com.dh.facade.service.proveedores.ProveedorA;
import com.dh.facade.service.proveedores.ProveedorB;
import com.dh.facade.service.proveedores.ProveedorC;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class Main {

    public static void main(String[] args) throws ParseException {
        IBuscadorFacade buscadorFacade = new BuscadorImpl(new ProveedorA(), new ProveedorB(), new ProveedorC());

        Date desde = new SimpleDateFormat("yyyy-MM-dd").parse("2021-06-29");
        Date hasta = new SimpleDateFormat("yyyy-MM-dd").parse("2021-07-07");
        List<Map<String, String>> vuelos = buscadorFacade.buscarVuelo(desde, hasta, "Argentina", "Colombia");
        vuelos.forEach(System.out::println);

    }
}
