package com.dh.facade.service.proveedores;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ProveedorA {

    public Map<String,String> buscar(Date fechaDesde, Date fechaHasta, String hasta, String desde){
        Map<String,String> vuelo = new HashMap<>();
        vuelo.put("vueloId","12");
        vuelo.put("desde","Ezeiza, Argentina");
        vuelo.put("hacia","Cali, Colombia");
        vuelo.put("fecha","30/6/2021");
        vuelo.put("valorDesde","$77.529");
        vuelo.put("proveedor","ProveedorA");
        return vuelo; //Para el caso practico, simulamos la llamada a otro servicio
    }
}
