package com.dh.facade.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface IBuscadorFacade {

    public List<Map<String,String>> buscarVuelo(Date fechaDesde,Date fechaHasta,String origen,String destino);
}
