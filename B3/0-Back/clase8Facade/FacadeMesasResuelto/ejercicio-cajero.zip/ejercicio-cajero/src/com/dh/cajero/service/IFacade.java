package com.dh.cajero.service;

public interface IFacade {

    public Boolean retirarDinero(String identificacionCliente, String contrasena, Integer montoARetirar);
}
