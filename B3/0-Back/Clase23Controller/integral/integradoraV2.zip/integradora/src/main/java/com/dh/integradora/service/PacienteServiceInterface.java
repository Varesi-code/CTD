package com.dh.integradora.service;

import com.dh.integradora.dominio.Paciente;

import java.util.List;

public interface PacienteServiceInterface {
    List<Paciente> listarPacientes();
    Paciente buscarXEmail(String email);
}
