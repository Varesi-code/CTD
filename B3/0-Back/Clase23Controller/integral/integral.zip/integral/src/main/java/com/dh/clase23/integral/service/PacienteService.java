package com.dh.clase23.integral.service;

import com.dh.clase23.integral.dominio.Paciente;

import java.util.List;

public class PacienteService implements PacienteServiceInterface{

    // trabajar con el DAO
    @Override
    public List<Paciente> listarPacientes() {
        return null;
    }

    @Override
    public Paciente buscarXEmail(String email) {
        return null;
    }
}
