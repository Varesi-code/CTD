package presencial;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Main {
   private static List<Perro> crearColección15Perros(){
      List<Perro> perritos = new ArrayList<> ();
      String nombre;
      int edad;
      HashMap<Integer, String> nombresPosibles = new HashMap<> ();

      nombresPosibles.put (1, "Pepito");
      nombresPosibles.put (2, "Laica");
      nombresPosibles.put (3, "Mamba");
      nombresPosibles.put (4, "Pepita");
      nombresPosibles.put (5, "Pepa");
      nombresPosibles.put (6, "Fisu");
      nombresPosibles.put (7, "Pepa");
      nombresPosibles.put (8, "Roco");
      nombresPosibles.put (9, "Roca");
      nombresPosibles.put (10, "Koki");
      nombresPosibles.put (11, "Hansel");
      nombresPosibles.put (12, "Suller");
      nombresPosibles.put (13, "Africa");
      nombresPosibles.put (14, "Centu");
      nombresPosibles.put (15, "Boby");
      nombresPosibles.put (16, "Pantuflas");
      nombresPosibles.put (17, "Salo");
      nombresPosibles.put (18, "Laica");
      nombresPosibles.put (19, "Gaucho");
      nombresPosibles.put (20, "Rocky");

      for (int i = 0; i <= 15; i++) {
         //buscar una edad random
         edad = (int)(Math.random ()*17-1)+1;

         //buscar un nombre random
         nombre = nombresPosibles.get((int)(Math.random()* 20-1)+1 );
         //crear un objeto perro con los datos anteriores
         Perro can = new Perro(edad, nombre);
         //agregar el objeto a la colección
         perritos.add (can);
      }

      return perritos;
   }



   public static void main (String[] args) {
      //crear nuestra colección de perros
      List<Perro> perros = new ArrayList<> ();

      perros = crearColección15Perros ();

 /*   perros.add (new Perro(8, "Pepito"));
      perros.add (new Perro(5, "Laica"));
      perros.add (new Perro(4, "Mamba"));
      perros.add (new Perro(2, "Pepita"));*/

      //guardar en un archivo nuestra colección

      //cuando voy a escribir en un archivo
      FileOutputStream fos;
      try {
         fos = new FileOutputStream ("PerritosGuardados.txt");
         ObjectOutputStream oos = new ObjectOutputStream (fos);
         oos.writeObject (perros);
         oos.close ();
      } catch (FileNotFoundException e) {
         e.printStackTrace ();
      } catch (IOException e) {
         e.printStackTrace ();
      }
      //recuperar la colección desde un archivo a otra colección en java
      List<Perro> perrosRecuperados = null;

      //cuando voy a leer o recibir algo
      FileInputStream fis;

      try{
        fis = new FileInputStream ("PerritosGuardados.txt");
        ObjectInputStream ois = new ObjectInputStream (fis);

        //leemos el archivo
        perrosRecuperados = (List<Perro>) ois.readObject ();
         ois.close ();

      } catch (FileNotFoundException e) {
         e.printStackTrace ();
      } catch (IOException e) {
         e.printStackTrace ();
      } catch (ClassNotFoundException e) {
         e.printStackTrace ();
      }

      //mostrar la colección recuperada mediante consola
      for (Perro p: perrosRecuperados) {
         System.out.println (p);
      }

      }
   }
