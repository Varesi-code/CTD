package mesa;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ManejoDeArchivos {
   private static void guardarContactos(List<Contacto> contactos) {


      FileOutputStream fos;

      try {
         fos = new FileOutputStream("contactos.txt");
         ObjectOutputStream oos = new ObjectOutputStream(fos);
         oos.writeObject (contactos);
         oos.close ();
      } catch (FileNotFoundException e) {
         e.printStackTrace ();
      } catch (IOException e) {
         e.printStackTrace ();
      }
   }
   private static void leerContactos(){
      List<Contacto> contactosRecuperados;
      FileInputStream fis;

      try{
         fis = new FileInputStream("contactos.txt");
         ObjectInputStream ois = new ObjectInputStream(fis);
         contactosRecuperados = (ArrayList) ois.readObject();
         ois.close ();

         for (Contacto contacto : contactosRecuperados) {
            System.out.println (contacto);
         }
         
      } catch (FileNotFoundException e) {
         e.printStackTrace ();
      } catch (IOException e) {
         e.printStackTrace ();
      } catch (ClassNotFoundException e) {
         e.printStackTrace ();
      }
   }


   public static void main (String[] args) {
      List<Contacto> contactos = new ArrayList<> ();
      contactos.add (new Contacto ("Juan", "perez@gmail.com", "123"));
      contactos.add (new Contacto ("Jose", "jose@gmail.com", "111"));
      contactos.add (new Contacto ("Pampa", "pampa@gmail.com", "222"));
      contactos.add (new Contacto ("Guido", "guido@gmail.com", "333"));
      contactos.add (new Contacto ("Feli", "feli@gmail.com", "333"));
      contactos.add (new Contacto ("Nati", "nati@gmail.com", "444"));
      contactos.add (new Contacto ("Tana", "tana@gmail.com", "555"));
      contactos.add (new Contacto ("Bla", "bla@gmail.com", "666"));
      contactos.add (new Contacto ("Pepe", "pepa@gmail.com", "777"));


     guardarContactos (contactos);
     leerContactos ();
   }
}
