DROP TABLE IF EXISTS odontologos;
CREATE TABLE odontologos (
matricula INT NOT NULL,
nombre VARCHAR(50) NOT NULL,
apellido VARCHAR(50) NOT NULL);

--INSERT INTO odontologos VALUES (1456, 'Gabriela', 'Perez');
--INSERT INTO odontologos VALUES (22134, 'Pedro', 'Martinez');
--INSERT INTO odontologos VALUES (3789, 'Maria', 'Lopez');
--INSERT INTO odontologos VALUES (43246, 'Ana', 'Gonzalez');
--INSERT INTO odontologos VALUES (5789, 'Juan', 'Torres');