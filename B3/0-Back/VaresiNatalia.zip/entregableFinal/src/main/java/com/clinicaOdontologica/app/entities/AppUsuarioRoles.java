package com.clinicaOdontologica.app.entities;

public enum AppUsuarioRoles {
    ROLE_USER,
    ROLE_ADMIN
}
