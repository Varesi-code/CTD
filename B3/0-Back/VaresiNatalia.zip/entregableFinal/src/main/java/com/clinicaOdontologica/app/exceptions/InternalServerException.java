package com.clinicaOdontologica.app.exceptions;

public class InternalServerException extends Exception {
    public InternalServerException(String message) {
        super(message);
    }
}
