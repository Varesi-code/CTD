package presencial;

public class Programa {
    public static void main(String[] args) {
        App aplicacion = new App();
        aplicacion.agregarEntero(54);
        aplicacion.agregarEntero(81);
        aplicacion.agregarEntero(85);
        aplicacion.agregarEntero(12);
        aplicacion.agregarEntero(2);
        aplicacion.agregarEntero(22);
        aplicacion.maximoYMinimo();
        aplicacion.promedio();
    }

}
