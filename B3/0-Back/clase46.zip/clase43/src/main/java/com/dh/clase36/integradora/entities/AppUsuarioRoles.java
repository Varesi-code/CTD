package com.dh.clase36.integradora.entities;

public enum AppUsuarioRoles {
    ROLE_USER
}
