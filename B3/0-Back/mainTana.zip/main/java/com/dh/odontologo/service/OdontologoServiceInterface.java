package com.dh.odontologo.service;
import com.dh.odontologo.domain.Odontologo;
import java.util.List;

public interface OdontologoServiceInterface {
   List<Odontologo> listaOdontologos();
}
