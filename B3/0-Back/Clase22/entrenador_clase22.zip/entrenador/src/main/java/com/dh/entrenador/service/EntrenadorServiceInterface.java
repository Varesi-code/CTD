package com.dh.entrenador.service;

import com.dh.entrenador.dominio.Entrenador;

import java.util.List;

public interface EntrenadorServiceInterface {
    List<Entrenador> listaEntrenadores();
}
