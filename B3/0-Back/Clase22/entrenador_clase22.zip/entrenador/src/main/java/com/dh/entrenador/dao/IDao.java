package com.dh.entrenador.dao;

import java.util.List;

public interface IDao <T>{
    List<T> buscarElementos();
}
