package mesa;

public interface Descarga {
    String descarga(Usuario usuario);
}
