package presencial;

public interface Registro {
    String vacunar(Persona persona);
}
