package com.dh.integradora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegradoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
