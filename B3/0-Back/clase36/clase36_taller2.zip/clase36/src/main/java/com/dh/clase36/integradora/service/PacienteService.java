package com.dh.clase36.integradora.service;

import com.dh.clase36.integradora.entities.Paciente;
import com.dh.clase36.integradora.repository.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class PacienteService{
    @Autowired
    PacienteRepository repository;

    public List<Paciente> buscarTodos(){
        return repository.findAll();
    }

    public Paciente guardar(Paciente p){
        return repository.save(p);
    }

    public void eliminar(Long id){
        repository.deleteById(id);
    }

    /*public Paciente buscar(Long id){
        Optional<Paciente> pas=repository.findById(id);
        if (pas.isPresent()){
            return pas.get();
        }
        else{
            return null;
        }

    }

     */

    public Optional<Paciente> buscar(Long id){
        return repository.findById(id);
    }

    public Paciente actualizar(Paciente p){
        Optional<Paciente> pacienteBuscado=buscar(p.getId());
        if (pacienteBuscado.isPresent())
            return repository.save(p);
        else
            return null;
    }

}
