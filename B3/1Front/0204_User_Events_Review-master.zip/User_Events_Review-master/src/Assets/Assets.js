export const GoogleLogo = "https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Google_%22G%22_Logo.svg/2048px-Google_%22G%22_Logo.svg.png";
export const FaceBookLogo = "https://cdn-icons-png.flaticon.com/512/124/124010.png";
export const AppleLogo = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Apple_logo_hollow.svg/1720px-Apple_logo_hollow.svg.png";
export const Loading = "https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif";
export const LoggedInSucess = "https://guportal.in/img/success.png";