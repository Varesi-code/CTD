const data = [
  {
    username: "Kike",
    email: "kike@gmail.com",
    password: "jaider1234"
  },{
    username: "laura",
    email: "laura@gmail.com",
    password: "Laura1234"
  },{
    username: "Camilo",
    email: "Camilo@gmail.com",
    password: "camila1234"
  },{
    username: "Camila",
    email: "Camila@gmail.com",
    password: "camila1234"
  }
];
