export const UserRegistered = {
    name: "Camilation",
    email: "camilo@gmail.com",
    password: "camilo1234"
};