# Crazy Colors

En este ejercicio tendras que refactorizar el codigo dentro de App.jsx. En el mismo deberan implementar lo aprendido del state y setState

### Pasos para correr el proyecto

Relizar primero `npm install`
Relizar segundo `npm start`