import React from "react";

const User = (props) => {
  return <div>{props.name}</div>;
};

export default User;
