export const dataBlogs = [
    {
        id: 1,
        title: "The turth within ourselves!",
        content: "Many people have always opted for looking out for answers outside, when all they ever had to do was to find answers within themselves...",
        author: "Kumo Spatti Rose",
        date: "June/ 22 / 2020"
    },{
        id: 2,
        title: "The past still present!",
        content: "Many people have always opted for looking out for answers in the past, when all they ever had to do was to find answers in the present...",
        author: "Jay Ray Holt",
        date: "July/ 23 / 2020"
    },{
        id: 3,
        title: "The survivor of dreams!",
        content: "Many people have always opted for looking out for answers in the reality they are living, when all they ever had to do was to find answers within their dreams...",
        author: "Dylan Osten Howard",
        date: "August/ 24 / 2020"
    },{
        id: 4,
        title: "The river of blood and passion!",
        content: "Many people have always opted for looking out for answers in their river of blood, when all they ever had to do was to find answers within their passions...",
        author: "Patrick Hays",
        date: "September/ 22 / 2020"
    }
]