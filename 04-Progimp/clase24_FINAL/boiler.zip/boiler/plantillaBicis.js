const v = "\x1b[32m%s\x1b[0m"; // NO TOCAR
const o = "*".repeat(80) + "\n"; // NO TOCAR
const oo = "*".repeat(25); // NO TOCAR

/*******************************/
/* Desarrollo de las consignas */
/*******************************/

// A

// B

// C

// D

// E

// F

// G

// H

// I

// J

// K

// L
/******************************/
/* Ejecución de las consignas */
/******************************/

console.log(v, "\n" + oo + " .D. ");
// Ejecución aquí
console.log(o);

console.log(v, oo + " .E.");
// Ejecución aquí
console.log(o);

console.log(v, oo + " .F.");
// Ejecución aquí
console.log(o);

console.log(v, oo + " .G.");
// Ejecución aquí
console.log(o);

console.log(v, oo + " .H.");
// Ejecución aquí
console.log(o);

console.log(v, oo + " .I.");
// Ejecución aquí
console.log(o);

console.log(v, oo + " .J. ");
// Ejecución aquí
console.log(o);

console.log(v, oo + " .K. ");
// Ejecución aquí
console.log(o);

console.log(v, oo + " .L. ");
// Ejecución aquí
console.log(o);
