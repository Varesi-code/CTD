public interface Pizza {
    public double getPrecio();
    public String getNombre();
    public String getDescripcion();

}
