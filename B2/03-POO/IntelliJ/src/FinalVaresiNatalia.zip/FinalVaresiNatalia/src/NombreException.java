public class NombreException extends Exception {
    public NombreException(String mensaje) {
        super(mensaje);
    }
}
